#define YY_NO_UNPUT

#include<iostream>
#include<stdio.h>
#include<string>

using namespace std;


